
public class Test02 {

    public static void main(String[] args) {
        Prastevila prastevila = new Prastevila();
        for (int i = 0;  i < 10;  i++) {
            System.out.println(prastevila.naslednje());
        }
    }
}
