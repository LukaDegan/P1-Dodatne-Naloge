
public class Test02 {

    public static void main(String[] args) {
        Krozek krozek = new Krozek("atletika", 3, 15, 100);
        System.out.println(krozek.vrniNaziv());
    }
}
