
public class Test01 {

    public static void main(String[] args) {
        Ucenec ucenec = new Ucenec("Peter", "Oblak");
        System.out.println(ucenec.vrniIP());
    }
}
