
public class Test01 {

    public static void main(String[] args) {
        Filozof slavoj = new Filozof("Slavoj");
        Filozof renata = new Filozof("Renata");
        Filozof mladen = new Filozof("Mladen");
        Filozof tine = new Filozof("Tine");
        Filozof spomenka = new Filozof("Spomenka");
        System.out.println(slavoj.vrniIme());
        System.out.println(renata.vrniIme());
        System.out.println(mladen.vrniIme());
        System.out.println(tine.vrniIme());
        System.out.println(spomenka.vrniIme());
    }
}
