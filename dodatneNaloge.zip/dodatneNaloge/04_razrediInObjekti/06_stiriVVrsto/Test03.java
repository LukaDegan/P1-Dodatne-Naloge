
public class Test03 {

    public static void main(String[] args) {
        StiriVVrsto igra = new StiriVVrsto(2, 3);
        System.out.println(igra.naPotezi());
        System.out.println(igra.vrzi(1));
        System.out.println(igra.naPotezi());
        System.out.println(igra.vrzi(0));
        System.out.println(igra.naPotezi());
        System.out.println(igra.vrzi(1));
        System.out.println(igra.naPotezi());
        System.out.println(igra.vrzi(2));
        System.out.println(igra.naPotezi());
        System.out.println(igra.vrzi(1));
        System.out.println(igra.naPotezi());
        System.out.println(igra.vrzi(0));
        System.out.println(igra.naPotezi());
        System.out.println(igra.vrzi(2));
        System.out.println(igra.naPotezi());
        System.out.println(igra.vrzi(2));
        System.out.println(igra.naPotezi());
        System.out.println(igra.vrzi(0));
        System.out.println(igra.naPotezi());
        System.out.println(igra.vrzi(2));
        System.out.println(igra.naPotezi());
    }
}
